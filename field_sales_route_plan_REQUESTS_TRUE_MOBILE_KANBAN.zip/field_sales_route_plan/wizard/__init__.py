from . import sales_route_add_partner_wizard
from . import route_sale_terminal_wizard
from . import visit_purpose_wizard

from . import marketing_visit_quick_wizard
from . import quick_route_plan_wizard

from . import route_plan_add_client_wizard

from . import license_activation_wizard

from . import sales_marketing_period_wizard
